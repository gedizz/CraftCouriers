instagramPostOne = document.querySelector("#insta1");
instagramPostTwo = document.querySelector("#insta2");
instagramPostThree = document.querySelector("#insta3");
instagramPostFour = document.querySelector("#insta4");


instagramPostOne.addEventListener("click", () => {
    window.location.replace("https://www.instagram.com/p/Cd_DqmDBify/?utm_source=ig_web_copy_link");
});

instagramPostTwo.addEventListener("click", () => {
    window.location.replace("https://www.instagram.com/p/CXtsRCrl97V/?utm_source=ig_web_copy_link");
});

instagramPostThree.addEventListener("click", () => {
    window.location.replace("https://www.instagram.com/p/CNSdroPgxnL/?utm_source=ig_web_copy_link");
});

instagramPostFour.addEventListener("click", () => {
    window.location.replace("https://www.instagram.com/p/Cd3mFBGMdNs/?utm_source=ig_web_copy_link");
});
